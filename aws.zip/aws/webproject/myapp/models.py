from django.db import models
from datetime import datetime
from django.core.validators import RegexValidator
# Create your models here.

class Shop(models.Model):
    company=models.CharField(max_length=100)
    software=models.CharField(max_length=100)
    type=models.CharField(max_length=20)
    description=models.TextField()
    

    def __str__(self):
        return self.company
    
class productDetail(models.Model):
    company=models.CharField(max_length=100)
    software=models.CharField(max_length=100)
    website=models.URLField(max_length=200)
    type=models.CharField(max_length=20)
    description=models.TextField()
    location=models.CharField(max_length=100)
    cities=models.CharField(max_length=100)
    Telephone=models.IntegerField(null=True, unique=True, validators=[RegexValidator(regex='^([+]?[\s0-9]+)?(\d{3}|[(]?[0-9]+[)])?([-]?[\s]?[0-9])+$', message='Length has to be 12', code='Invalid number')])
    
    def __str__(self):
        return self.company
    