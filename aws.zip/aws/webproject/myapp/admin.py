from django.contrib import admin
from .models import Shop,productDetail
# Register your models here.

admin.site.register(Shop)
admin.site.register(productDetail)