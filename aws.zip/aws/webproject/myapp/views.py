from django.shortcuts import render
from django.http import HttpResponse
from .models import Shop,productDetail

# Create your views here.
def home(request):
    return render(request, "Vendor.html")

def product(request):
    post=Shop.objects.get(company="Addepar, INC")
    post1=Shop.objects.get(company="Alveo")
    post2=Shop.objects.get(company="CloudAttrbution") 
    
    return render(request, "productlist.html",{'post':post,'post1':post1,'post2':post2}) 

def productdetail(request):
    prod=productDetail.objects.get(company="ADDEPAR, INC.")
    
    return render(request, "productdetail.html",{'prod':prod})

def productdetail1(request):
    prod1=productDetail.objects.get(company="Alveo")
    
    return render(request, "productdetail1.html",{'prod1':prod1})